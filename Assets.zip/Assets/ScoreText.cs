﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreText : MonoBehaviour
{
    int score1 = 0;
    int score2 = 0;
    public GameObject ball;
    bool score = true;
    int logBounce = 0;
    // Start is called before the first frame update
    void Start()
    {
      Screen.orientation = ScreenOrientation.LandscapeLeft;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameObject.Find("ballObj")){
            ball = GameObject.Find("ballObj");
            if (ball.transform.position.y > 0){
              score = true;
            }
            if (ball.transform.position.z < 0 && ball.transform.position.y < 0.72){
              if (logBounce == 1){
                logBounce = 0;
                if (score == true) score2++;
                ball.transform.position = new Vector3(0,4,0);
                ball.GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
              }
              logBounce = 1;
            }
            if (ball.transform.position.z > 0 && ball.transform.position.y < 0.72){
              if (logBounce == 2){
                logBounce = 0;
                if (score == true) score1++;
                ball.transform.position = new Vector3(0,4,0);
                ball.GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
              }
              logBounce = 2;
            }

            if (ball.transform.position.y < 0 && ball.transform.position.z > 0) {
              if (score == true) score1++;
              logBounce = 0;
              score = false;
            }
            else if (ball.transform.position.y < 0 && ball.transform.position.z <= 0){
              if (score == true) score2++;
              logBounce = 0;
              score = false;
            }

          /*  if (ball.transform.position.y < 2 && ball.transform.position.z == 0 && ball.GetComponent<Rigidbody>().velocity.z > 0){
              if (score == true) score2++;
              ball.transform.position = new Vector3(0,4,0);
              ball.GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
            }

            if (ball.transform.position.y < 2 && ball.transform.position.z == 0 && ball.GetComponent<Rigidbody>().velocity.z < 0){
              if (score == true) score1++;
              ball.transform.position = new Vector3(0,4,0);
              ball.GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
            }*/
         }


        GetComponent<UnityEngine.UI.Text>().text =  score1 + "-" + score2;
    }
}
