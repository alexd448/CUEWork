﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CamSpawn : NetworkBehaviour
{
    public Camera camHost;
    public Camera camClient;
    //public GameObject ballObj;
    // Start is called before the first frame update
    void Start()
    {
      //camClient.transform.position = new Vector3(0, 2.5f, -16);
      //camClient.transform.rotation = new Quaternion (0, 0, 0, 0);
    }
    // Update is called once per frame

    void Update()
    {
      if (!isLocalPlayer){
          camHost.enabled = false;
      }

      camClient.enabled = true;
      //CmdSwing();

    }

    //[Command]
    /*void CmdSwing(){
      if (Input.acceleration.x > 0.75 || Input.acceleration.y > 1.25 || Input.acceleration.z > 1 ||
            Input.acceleration.x < -0.75 || Input.acceleration.y < -1.25 || Input.acceleration.z < -1) {

              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < 0 &&
                  ballObj.transform.position.z >= - 3)
                 {
                   ballObj.GetComponent<Rigidbody>().velocity = new Vector3(-3, 2, 8);
                 }

              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < -3 && ballObj.transform.position.z >= - 6){
                ballObj.GetComponent<Rigidbody>().velocity = new Vector3(-1, 4, 8);
              }
              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < -6 && ballObj.transform.position.z >= -10){
                ballObj.GetComponent<Rigidbody>().velocity = new Vector3(1, 6, 8);
              }
      }*/
  }
