﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class ColorScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
      GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
    }

    // Update is called once per frame

    void OnCollisionEnter (Collision col)
    {
      int miss = Random.Range(0, 50);
      if (col.gameObject.name == "Racket" && GetComponent<Rigidbody>().position.y <= 2){
        if (miss < 13){
          GetComponent<Rigidbody>().velocity = new Vector3(0, 1, -20);
        }
        else {
          GetComponent<Rigidbody>().velocity = new Vector3(0, 9, -8);
        }
      }
      if (col.gameObject.name == "Racket" && GetComponent<Rigidbody>().position.y > 2 && GetComponent<Rigidbody>().position.y <= 5){
        if (miss < 8){
          GetComponent<Rigidbody>().velocity = new Vector3(0, 3.5f, -4);
        }
        else {
          GetComponent<Rigidbody>().velocity = new Vector3(0, 7, -8);
        }
      }
      if (col.gameObject.name == "Racket" && GetComponent<Rigidbody>().position.y > 5) {
        if (miss < 8){
          GetComponent<Rigidbody>().velocity = new Vector3(20, 1, -8);
        }
        else {
          GetComponent<Rigidbody>().velocity = new Vector3(0, 6, -8);
        }
      }

      if (col.gameObject.name == "Net" && GetComponent<Rigidbody>().position.y > 0){
        GameObject.Find("Text").GetComponent<UnityEngine.UI.Text>().text =  "Collided";
        GetComponent<Transform>().position = new Vector3(0, 0.5f, GetComponent<Rigidbody>().position.z);
        GetComponent<Rigidbody>().velocity = new Vector3(0,0,0);
      }

     }

    void Update()
    {
      /*if (Input.acceleration.x > 0.75 || Input.acceleration.y > 1.25 || Input.acceleration.z > 1 ||
            Input.acceleration.x < -0.75 || Input.acceleration.y < -1.25 || Input.acceleration.z < -1) {

              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < 0 &&
                 GetComponent<Transform>().position.z >= - 3)
                 {
                   GetComponent<Rigidbody>().velocity = new Vector3(-3, 2, 8);
                 }

              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < -3 && GetComponent<Transform>().position.z >= - 6){
                GetComponent<Rigidbody>().velocity = new Vector3(-1, 4, 8);
              }
              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < -6 && GetComponent<Transform>().position.z >= -10){
                GetComponent<Rigidbody>().velocity = new Vector3(1, 6, 8);
              }
            }*/
      if (GetComponent<Rigidbody>().position.y < -5){
          GetComponent<Rigidbody>().position = new Vector3(0,4,0);
          GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
        }
      }
}
