﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CamSwing : NetworkBehaviour
{
    public GameObject ballObj;
    // Start is called before the first frame update
    void Start()
    {

    }

    [Command]
    void CmdSwing(){
      int y = 0;
      int x = 0;
      int z = 7;
      if (Input.acceleration.x > 0.75 || Input.acceleration.y > 1.25 || Input.acceleration.z > 1 ||
            Input.acceleration.x < -0.75 || Input.acceleration.y < -1.25 || Input.acceleration.z < -1) {
              if (Input.acceleration.y < 0) {
                  y = 8;
                  z = z - 1;
              }
              else if (Input.acceleration.y > 0){
                  y = 4;
                  z = z + 2;
              }
              if (Input.acceleration.x < 0){
                x = -1;
              }
              else if (Input.acceleration.x > 0){
                x = 1;
              }

              if (ballObj.transform.position.x < 0){
                x = x + 2;
              }
              else if (ballObj.transform.position.x < 0){
                x = x - 2;
              }

              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < -3 &&
                  ballObj.transform.position.z >= -4)
                 {
                   ballObj.GetComponent<Rigidbody>().velocity = new Vector3(x - 2, y, z);
                 }

              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < -6 && ballObj.transform.position.z >= - 7){
                ballObj.GetComponent<Rigidbody>().velocity = new Vector3(x, y, z);
              }
              if (ballObj.GetComponent<Rigidbody>().velocity.z < 0 && ballObj.transform.position.z < -8 && ballObj.transform.position.z >= -10){
                ballObj.GetComponent<Rigidbody>().velocity = new Vector3(x + 2, y, z);
              }
      }
    }

    // Update is called once per frame
    void Update()
    {
      if (!isLocalPlayer)
      {
        return;
      }
      CmdSwing();
    }


}
