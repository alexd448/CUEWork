﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class BallSpawn : NetworkBehaviour
{
    public GameObject ballObject;
    // Start is called before the first frame update
    void Start()
    {
        //CmdSpawn();
    }
    // Update is called once per frame

    void Update()
    {
      //CmdSwing();
      //if (!isLocalPlayer){
      //return;
      //}
    }

    [Command]
    void CmdSpawn()
    {
      NetworkServer.Spawn(ballObject);
    }

    [Command]
    void CmdSwing()
    {
      if (Input.acceleration.x > 0.75 || Input.acceleration.y > 1.25 || Input.acceleration.z > 1 ||
            Input.acceleration.x < -0.75 || Input.acceleration.y < -1.25 || Input.acceleration.z < -1) {

              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < 0 &&
                 GetComponent<Transform>().position.z >= - 3)
                 {
                   GetComponent<Rigidbody>().velocity = new Vector3(-3, 2, 8);
                 }

              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < -3 && GetComponent<Transform>().position.z >= - 6){
                GetComponent<Rigidbody>().velocity = new Vector3(-1, 4, 8);
              }
              if (GetComponent<Rigidbody>().velocity.z < 0 && GetComponent<Transform>().position.z < -6 && GetComponent<Transform>().position.z >= -10){
                GetComponent<Rigidbody>().velocity = new Vector3(1, 6, 8);
              }
            }
        if (GetComponent<Rigidbody>().position.y < -5){
              GetComponent<Rigidbody>().position = new Vector3(0,4,0);
              GetComponent<Rigidbody>().velocity = new Vector3(2,2,5);
        }
    }
}
