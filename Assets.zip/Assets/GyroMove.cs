﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GyroMove : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.acceleration.x > 0.5 || Input.acceleration.y > 0.5 || Input.acceleration.z > 0.5 ||
              Input.acceleration.x < -0.5 || Input.acceleration.y < - 0.5 || Input.acceleration.z < -0.5) {
                transform.Translate(Input.acceleration.x, 0, -Input.acceleration.z);
        }
    }
}
