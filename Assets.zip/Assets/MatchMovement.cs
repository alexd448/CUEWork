﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MatchMovement : MonoBehaviour
{
    public GameObject ball;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
       if (GameObject.Find("ballObj")){
            ball = GameObject.Find("ballObj");
            if (ball.transform.position.y >= 0 && ball.transform.position.y <= 10 && ball.transform.position.x >= -15 && ball.transform.position.x <= 15) {
                GetComponent<Transform>().position = new Vector3 (ball.transform.position.x, ball.transform.position.y, 10);
            }
     }
    }
}
