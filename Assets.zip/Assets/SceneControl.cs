﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneControl : MonoBehaviour
{

    public void ChangeToPlay(){
        SceneManager.LoadScene("SampleScene");
    }

    public void ChangeToInstructions(){
        SceneManager.LoadScene("Instructions");
    }

    public void ChangeToTips(){
      SceneManager.LoadScene("Tips");
    }

    public void ChangeToMenu(){
      SceneManager.LoadScene("MenuScene");
    }
}
